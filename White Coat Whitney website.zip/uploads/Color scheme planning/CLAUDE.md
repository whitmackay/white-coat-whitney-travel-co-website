# Project pattern: decorative header border

Approved header treatment for White Coat Whitney Travel Co. pages (added to Website Homepage Mockup.dc.html). Reuse this exactly on any new page's header for consistency.

## Colors used (from _ds pop-color extension, define in each DC's <style>)
```css
:root{ --pop-lime:#C8E85A; --pop-pink:#F2A4C0; --pop-aperol:#F2622E; }
```
(--wcw-blue comes from the design system's colors.css already.)

## Top-of-page ribbon (G6 — cycling pinstripe)
```html
<div style="height:36px;background:repeating-linear-gradient(90deg, var(--wcw-blue) 0 6px, transparent 6px 30px, var(--pop-aperol) 30px 36px, transparent 36px 60px, var(--pop-pink) 60px 66px, transparent 66px 90px, var(--pop-lime) 90px 96px, transparent 96px 120px);border-top:1px solid var(--wcw-line);border-bottom:1px solid var(--wcw-line)"></div>
```

## Break lines flanking the nav menu
```html
<div style="display:flex;align-items:center;gap:14px;margin-top:40px;width:100%;max-width:520px">
  <div style="flex:1;height:2px;background:repeating-linear-gradient(90deg, var(--wcw-blue) 0 4px, var(--pop-aperol) 4px 8px, var(--pop-pink) 8px 12px, var(--pop-lime) 12px 16px)"></div>
  <nav style="...">...</nav>
  <div style="flex:1;height:2px;background:repeating-linear-gradient(90deg, var(--wcw-blue) 0 4px, var(--pop-aperol) 4px 8px, var(--pop-pink) 8px 12px, var(--pop-lime) 12px 16px)"></div>
</div>
```

Header structure: ribbon → centered logo (height:96px, ./assets/logo-transparent.png) → break-lines-flanked nav, all inside a sticky header on --wcw-cream with a bottom hairline border.
