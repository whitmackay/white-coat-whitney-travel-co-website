Small status label — trip status, inquiry state.

```jsx
<Badge tone="accent">In progress</Badge>
```
