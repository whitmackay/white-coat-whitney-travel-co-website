import React from 'react';
export interface BadgeProps {
  tone?: 'neutral' | 'accent' | 'success' | 'warning';
  children?: React.ReactNode;
}
