import React from 'react';
export function Badge({tone='neutral', children}) {
  const tones = {
    neutral:{background:'var(--wcw-sand)', color:'var(--text-secondary)'},
    accent:{background:'var(--color-accent-wash)', color:'var(--wcw-blue-dark)'},
    success:{background:'var(--pop-lime)', color:'var(--wcw-black)'},
    warning:{background:'#FBF0DF', color:'#9C6519'},
    pop:{background:'var(--pop-aperol)', color:'#fff'}
  };
  return React.createElement('span', {
    style:{...tones[tone], fontFamily:'var(--font-mono)', fontSize:11, letterSpacing:'0.06em', textTransform:'uppercase', padding:'4px 10px', borderRadius:'var(--radius-sm)', display:'inline-block'}
  }, children);
}
