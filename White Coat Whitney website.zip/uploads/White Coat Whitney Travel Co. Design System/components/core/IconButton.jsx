import React from 'react';
export function IconButton({icon, label, variant='ghost', onClick}) {
  const variants = {
    ghost:{background:'transparent', border:'1px solid transparent', color:'var(--text-primary)'},
    outline:{background:'transparent', border:'1px solid var(--border-subtle)', color:'var(--text-primary)'}
  };
  return React.createElement('button', {
    'aria-label':label, onClick, title:label,
    style:{...variants[variant], width:40, height:40, borderRadius:'var(--radius-sm)', display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', transition:'background var(--duration-fast) var(--ease-standard)'},
    onMouseEnter:e=>e.currentTarget.style.background='var(--wcw-sand)',
    onMouseLeave:e=>e.currentTarget.style.background='transparent'
  }, React.createElement('i', {'data-lucide':icon, style:{width:18,height:18}}));
}
