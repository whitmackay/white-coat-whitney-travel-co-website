Primary action button in the mono/uppercase brand voice — use for the single most important action in a section (e.g. "Inquire").

```jsx
<Button variant="primary" size="md" onClick={submit}>Inquire</Button>
```

Variants: `primary` (solid black), `accent` (sky-blue fill, use sparingly), `outline` (hairline border), `ghost` (text only). Sizes: `sm`, `md`, `lg`.
