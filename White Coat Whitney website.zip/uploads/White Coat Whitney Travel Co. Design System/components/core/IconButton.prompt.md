Icon-only affordance (menu, close, chevrons) rendered with Lucide icons at the logo's hairline stroke weight.

```jsx
<IconButton icon="menu" label="Open menu" onClick={openNav} />
```

`icon` is any Lucide icon name (requires the Lucide script + `lucide.createIcons()` on mount). Use `outline` variant when it needs to read as a standalone control.
