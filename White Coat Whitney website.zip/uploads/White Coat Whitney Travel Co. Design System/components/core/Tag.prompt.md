Pill-shaped removable filter chip — destination filters, interest tags on an inquiry.

```jsx
<Tag onRemove={() => removeTag('Coastal')}>Coastal</Tag>
```
