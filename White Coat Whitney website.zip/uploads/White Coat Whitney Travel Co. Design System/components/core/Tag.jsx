import React from 'react';
export function Tag({children, onRemove, pop}) {
  const popStyles = {lime:{background:'var(--pop-lime)', color:'var(--wcw-black)', border:'1px solid var(--pop-lime)'}, pink:{background:'var(--pop-pink)', color:'var(--wcw-black)', border:'1px solid var(--pop-pink)'}, aperol:{background:'var(--pop-aperol)', color:'#fff', border:'1px solid var(--pop-aperol)'}};
  const style = pop ? popStyles[pop] : {background:'transparent', border:'1px solid var(--border-subtle)', color:'var(--text-secondary)'};
  return React.createElement('span', {
    style:{display:'inline-flex', alignItems:'center', gap:6, borderRadius:'var(--radius-pill)', padding:'5px 12px 5px 14px', fontFamily:'var(--font-body)', fontSize:14, ...style}
  }, children, onRemove && React.createElement('button', {
    onClick:onRemove, 'aria-label':'Remove',
    style:{border:'none', background:'none', cursor:'pointer', color:'var(--text-muted)', fontSize:14, padding:0, lineHeight:1}
  }, '×'));
}
