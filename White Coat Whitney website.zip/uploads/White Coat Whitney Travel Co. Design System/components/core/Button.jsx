import React from 'react';
export function Button({variant='primary', size='md', disabled=false, children, onClick}) {
  const sizes = {sm:{padding:'8px 18px',fontSize:14}, md:{padding:'12px 26px',fontSize:15}, lg:{padding:'16px 34px',fontSize:16}};
  const base = {
    fontFamily:'var(--font-mono)', letterSpacing:'0.08em', textTransform:'uppercase',
    borderRadius:'var(--radius-sm)', cursor: disabled ? 'not-allowed' : 'pointer',
    border:'1px solid transparent', transition:'all var(--duration-fast) var(--ease-standard)',
    opacity: disabled ? 0.4 : 1, ...sizes[size]
  };
  const variants = {
    primary:{background:'var(--wcw-black)', color:'#fff', borderColor:'var(--wcw-black)'},
    accent:{background:'var(--color-accent)', color:'var(--wcw-black)', borderColor:'var(--color-accent)'},
    outline:{background:'transparent', color:'var(--wcw-black)', borderColor:'var(--pop-lime)'},
    ghost:{background:'transparent', color:'var(--pop-pink)', borderColor:'transparent'},
    pop:{background:'var(--pop-aperol)', color:'#fff', borderColor:'var(--pop-aperol)'}
  };
  const disabledStyle = disabled ? {background:'var(--pop-aperol)', color:'#fff', borderColor:'var(--pop-aperol)', opacity:0.55} : {};
  return React.createElement('button', {
    disabled, onClick,
    style:{...base, ...variants[variant], ...disabledStyle},
    onMouseDown:e=>{ if(!disabled) e.currentTarget.style.transform='scale(0.98)'; },
    onMouseUp:e=>{ e.currentTarget.style.transform='scale(1)'; },
    onMouseEnter:e=>{ if(disabled) return; if(variant==='primary') e.currentTarget.style.background='#000'; if(variant==='outline') e.currentTarget.style.background='var(--pop-lime)'; if(variant==='ghost') e.currentTarget.style.background='var(--pop-pink)'; if(variant==='pop') e.currentTarget.style.opacity='0.85'; },
    onMouseLeave:e=>{ e.currentTarget.style.transform='scale(1)'; if(variant==='primary') e.currentTarget.style.background='var(--wcw-black)'; if(variant==='outline'||variant==='ghost') e.currentTarget.style.background='transparent'; if(variant==='pop') e.currentTarget.style.opacity='1'; }
  }, children);
}
