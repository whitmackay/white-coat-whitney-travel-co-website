import React from 'react';
export interface IconButtonProps {
  icon: string;
  label: string;
  variant?: 'ghost' | 'outline';
  onClick?: () => void;
}
