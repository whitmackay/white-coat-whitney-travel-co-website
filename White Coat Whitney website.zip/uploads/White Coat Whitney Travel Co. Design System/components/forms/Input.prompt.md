Text field for the inquiry/contact form — dates, names, destinations.

```jsx
<Input label="Preferred dates" placeholder="Oct 12 – Oct 19" />
```

Pass `error` to show a red hairline + message; omit for the default neutral state.
