import React from 'react';
export function Radio({label, checked, onChange}) {
  return React.createElement('label', {style:{display:'flex', alignItems:'center', gap:10, cursor:'pointer', fontFamily:'var(--font-body)', fontSize:16, color:'var(--text-primary)'}},
    React.createElement('span', {
      onClick:()=>onChange && onChange(),
      style:{width:18, height:18, borderRadius:'50%', border:'1px solid var(--border-strong)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0}
    }, checked && React.createElement('span', {style:{width:10, height:10, borderRadius:'50%', background:'var(--wcw-black)'}})),
    label
  );
}
