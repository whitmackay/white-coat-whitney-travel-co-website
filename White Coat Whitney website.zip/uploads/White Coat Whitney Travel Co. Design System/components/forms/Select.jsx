import React from 'react';
export function Select({label, options=[], value, onChange}) {
  return React.createElement('div', {style:{display:'flex', flexDirection:'column', gap:6, fontFamily:'var(--font-body)'}},
    label && React.createElement('label', {style:{fontFamily:'var(--font-mono)', fontSize:11, letterSpacing:'0.08em', textTransform:'uppercase', color:'var(--text-muted)'}}, label),
    React.createElement('select', {
      value, onChange,
      style:{fontFamily:'var(--font-body)', fontSize:17, padding:'12px 14px', borderRadius:'var(--radius-sm)', border:'1px solid var(--border-subtle)', background:'var(--wcw-white)', color:'var(--text-primary)', outline:'none'}
    }, options.map(o => React.createElement('option', {key:o, value:o}, o)))
  );
}
