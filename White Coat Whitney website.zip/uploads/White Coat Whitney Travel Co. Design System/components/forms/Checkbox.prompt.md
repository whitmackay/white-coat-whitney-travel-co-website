Square check for multi-select options (amenities, interests).

```jsx
<Checkbox label="Includes flights" checked={v} onChange={setV} />
```
