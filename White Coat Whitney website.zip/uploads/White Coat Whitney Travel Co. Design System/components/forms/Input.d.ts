import React from 'react';
export interface InputProps {
  label?: string;
  placeholder?: string;
  type?: string;
  helpText?: string;
  error?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}
