import React from 'react';
export function Input({label, placeholder, type='text', helpText, error, value, onChange}) {
  const [focused, setFocused] = React.useState(false);
  return React.createElement('div', {style:{display:'flex', flexDirection:'column', gap:6, fontFamily:'var(--font-body)'}},
    label && React.createElement('label', {style:{fontFamily:'var(--font-mono)', fontSize:11, letterSpacing:'0.08em', textTransform:'uppercase', color:'var(--text-muted)'}}, label),
    React.createElement('input', {
      type, placeholder, value, onChange,
      onFocus:()=>setFocused(true), onBlur:()=>setFocused(false),
      style:{
        fontFamily:'var(--font-body)', fontSize:17, padding:'12px 14px', borderRadius:'var(--radius-sm)',
        border:`1px solid ${error ? 'var(--state-error)' : focused ? 'var(--color-accent)' : 'var(--border-subtle)'}`,
        outline:'none', background:'var(--wcw-white)', color:'var(--text-primary)',
        boxShadow: focused ? '0 0 0 3px var(--color-accent-wash)' : 'none', transition:'all var(--duration-fast) var(--ease-standard)'
      }
    }),
    (helpText || error) && React.createElement('span', {style:{fontSize:13, color: error ? 'var(--state-error)' : 'var(--text-muted)'}}, error || helpText)
  );
}
