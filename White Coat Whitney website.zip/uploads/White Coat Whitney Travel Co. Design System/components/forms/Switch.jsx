import React from 'react';
export function Switch({checked, onChange, label}) {
  return React.createElement('label', {style:{display:'flex', alignItems:'center', gap:10, cursor:'pointer', fontFamily:'var(--font-body)', fontSize:16, color:'var(--text-primary)'}},
    React.createElement('span', {
      onClick:()=>onChange && onChange(!checked),
      style:{width:38, height:22, borderRadius:'var(--radius-pill)', background: checked ? 'var(--color-accent)' : 'var(--wcw-line)', position:'relative', transition:'background var(--duration-fast) var(--ease-standard)', flexShrink:0}
    }, React.createElement('span', {style:{position:'absolute', top:2, left: checked ? 18 : 2, width:18, height:18, borderRadius:'50%', background:'#fff', transition:'left var(--duration-fast) var(--ease-standard)', boxShadow:'var(--shadow-sm)'}})),
    label
  );
}
