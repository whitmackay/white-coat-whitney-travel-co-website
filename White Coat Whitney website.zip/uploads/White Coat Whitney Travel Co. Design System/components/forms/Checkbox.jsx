import React from 'react';
export function Checkbox({label, checked, onChange}) {
  return React.createElement('label', {style:{display:'flex', alignItems:'center', gap:10, cursor:'pointer', fontFamily:'var(--font-body)', fontSize:16, color:'var(--text-primary)'}},
    React.createElement('span', {
      onClick:()=>onChange && onChange(!checked),
      style:{width:18, height:18, border:'1px solid var(--border-strong)', borderRadius:'var(--radius-xs)', display:'flex', alignItems:'center', justifyContent:'center', background: checked ? 'var(--wcw-black)' : 'transparent', flexShrink:0}
    }, checked && React.createElement('span', {style:{color:'#fff', fontSize:12, lineHeight:1}}, '✓')),
    label
  );
}
