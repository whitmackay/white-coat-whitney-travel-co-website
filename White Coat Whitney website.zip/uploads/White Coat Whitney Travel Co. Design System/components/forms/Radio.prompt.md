Single-select round option — cabin class, single-choice questions.

```jsx
<Radio label="Business class" checked={cabin==='business'} onChange={() => setCabin('business')} />
```
