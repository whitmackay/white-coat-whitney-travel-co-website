Binary toggle — e.g. "flexible dates," email opt-in.

```jsx
<Switch label="Flexible on dates" checked={v} onChange={setV} />
```
