Dropdown for a small fixed set of choices — trip type, cabin class, party size.

```jsx
<Select label="Trip type" options={['Leisure', 'Conference + leisure', 'Family']} />
```
