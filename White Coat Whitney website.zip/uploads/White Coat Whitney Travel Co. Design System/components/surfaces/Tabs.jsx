import React from 'react';
export function Tabs({tabs=[], active, onChange}) {
  return React.createElement('div', {style:{display:'flex', gap:28, borderBottom:'1px solid var(--border-subtle)'}},
    tabs.map(t => React.createElement('button', {
      key:t, onClick:()=>onChange && onChange(t),
      style:{
        background:'none', border:'none', cursor:'pointer', padding:'12px 0',
        fontFamily:'var(--font-mono)', fontSize:12, letterSpacing:'0.1em', textTransform:'uppercase',
        color: t===active ? 'var(--text-primary)' : 'var(--text-muted)',
        borderBottom: t===active ? '2px solid var(--color-accent)' : '2px solid transparent',
        marginBottom:-1, transition:'color var(--duration-fast) var(--ease-standard)'
      }
    }, t))
  );
}
