Section switcher — itinerary day-by-day, or filtering trip types.

```jsx
<Tabs tabs={['Overview','Itinerary','Inclusions']} active={tab} onChange={setTab} />
```
