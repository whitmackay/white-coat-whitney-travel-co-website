import React from 'react';
export function Card({image, eyebrow, title, body, footer}) {
  return React.createElement('div', {style:{border:'1px solid var(--border-subtle)', borderRadius:'var(--radius-md)', overflow:'hidden', background:'var(--wcw-white)', display:'flex', flexDirection:'column'}},
    image && React.createElement('img', {src:image, style:{width:'100%', height:160, objectFit:'cover', display:'block'}}),
    React.createElement('div', {style:{padding:20, display:'flex', flexDirection:'column', gap:8}},
      eyebrow && React.createElement('span', {style:{fontFamily:'var(--font-mono)', fontSize:11, letterSpacing:'0.08em', textTransform:'uppercase', color:'var(--text-muted)'}}, eyebrow),
      title && React.createElement('h3', {style:{fontFamily:'var(--font-display)', fontWeight:400, fontSize:24, margin:0, color:'var(--text-primary)'}}, title),
      body && React.createElement('p', {style:{fontFamily:'var(--font-body)', fontSize:16, color:'var(--text-secondary)', margin:0, lineHeight:'var(--leading-normal)'}}, body),
      footer && React.createElement('div', {style:{marginTop:8}}, footer)
    )
  );
}
