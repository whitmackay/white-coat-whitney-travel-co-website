import React from 'react';
export interface TabsProps {
  tabs?: string[];
  active?: string;
  onChange?: (tab: string) => void;
}
