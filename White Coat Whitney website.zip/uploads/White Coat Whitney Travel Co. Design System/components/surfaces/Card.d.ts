import React from 'react';
export interface CardProps {
  image?: string;
  eyebrow?: string;
  title?: string;
  body?: string;
  footer?: React.ReactNode;
}
