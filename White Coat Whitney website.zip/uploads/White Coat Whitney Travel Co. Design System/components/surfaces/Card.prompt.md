Editorial content card — border only, no shadow, small radius. Used for destination/trip listings.

```jsx
<Card image="/coast.jpg" eyebrow="Amalfi Coast" title="7 nights, private villa" body="Includes transfers, chef, and a half-day sail." />
```
