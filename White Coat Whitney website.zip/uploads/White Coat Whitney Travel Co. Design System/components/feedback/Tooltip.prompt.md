Hover hint for icon-only controls or truncated data.

```jsx
<Tooltip label="Round trip, business class"><IconButton icon="info" label="Info" /></Tooltip>
```
