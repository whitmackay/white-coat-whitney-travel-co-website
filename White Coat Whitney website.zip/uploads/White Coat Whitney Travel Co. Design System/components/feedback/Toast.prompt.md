Transient confirmation banner — "Your inquiry has been sent."

```jsx
<Toast tone="success" onClose={dismiss}>Inquiry sent — I'll reply within one business day.</Toast>
```
