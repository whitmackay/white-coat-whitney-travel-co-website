import React from 'react';
export function Dialog({open, title, children, onClose}) {
  if (!open) return null;
  return React.createElement('div', {
    style:{position:'absolute', inset:0, background:'rgba(16,19,20,0.5)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:100}
  }, React.createElement('div', {
    style:{background:'var(--wcw-white)', borderRadius:'var(--radius-md)', boxShadow:'var(--shadow-lg)', padding:32, maxWidth:420, width:'90%', fontFamily:'var(--font-body)'}
  },
    React.createElement('div', {style:{display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:16}},
      React.createElement('h3', {style:{fontFamily:'var(--font-display)', fontWeight:400, fontSize:26, margin:0, color:'var(--text-primary)'}}, title),
      React.createElement('button', {onClick:onClose, style:{background:'none', border:'none', cursor:'pointer', fontSize:18, color:'var(--text-muted)'}}, '×')
    ),
    children
  ));
}
