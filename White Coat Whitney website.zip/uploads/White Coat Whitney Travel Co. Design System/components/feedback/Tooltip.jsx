import React from 'react';
export function Tooltip({label, children}) {
  const [show, setShow] = React.useState(false);
  return React.createElement('span', {
    style:{position:'relative', display:'inline-block'},
    onMouseEnter:()=>setShow(true), onMouseLeave:()=>setShow(false)
  }, children,
    show && React.createElement('span', {
      style:{position:'absolute', bottom:'calc(100% + 8px)', left:'50%', transform:'translateX(-50%)', background:'var(--wcw-black)', color:'#fff', fontFamily:'var(--font-mono)', fontSize:11, padding:'6px 10px', borderRadius:'var(--radius-xs)', whiteSpace:'nowrap', zIndex:50}
    }, label)
  );
}
