import React from 'react';
export interface ToastProps {
  tone?: 'neutral' | 'success' | 'error';
  children?: React.ReactNode;
  onClose?: () => void;
}
