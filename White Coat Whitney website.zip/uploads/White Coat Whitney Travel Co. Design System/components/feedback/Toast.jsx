import React from 'react';
export function Toast({tone='neutral', children, onClose}) {
  const tones = {
    neutral:{background:'var(--wcw-black)', color:'#fff'},
    success:{background:'var(--pop-lime)', color:'var(--wcw-black)'},
    error:{background:'var(--state-error)', color:'#fff'}
  };
  return React.createElement('div', {
    style:{...tones[tone], fontFamily:'var(--font-body)', fontSize:15, padding:'14px 18px', borderRadius:'var(--radius-sm)', display:'flex', alignItems:'center', gap:14, boxShadow:'var(--shadow-md)', maxWidth:360}
  }, React.createElement('span', {style:{flex:1}}, children),
    onClose && React.createElement('button', {onClick:onClose, style:{background:'none', border:'none', color:'inherit', cursor:'pointer', fontSize:16}}, '×'));
}
