Modal confirmation — e.g. "inquiry sent" confirmation, itinerary preview.

```jsx
<Dialog open={open} title="Inquiry sent" onClose={close}>I'll reply within one business day.</Dialog>
```

Requires a `position: relative` ancestor to contain the overlay (an absolutely-positioned demo shell, not fixed to the viewport).
