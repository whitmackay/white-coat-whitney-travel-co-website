# Website UI Kit

Click-through recreation of the White Coat Whitney Travel Co. marketing site: `Home` (hero, featured trips, testimonial), `Trip Proposal` (itinerary/inclusions/investment tabs), and `Inquire` (contact form → confirmation). Navigate via the header. Composed entirely from `components/` primitives — no re-implemented UI.

Hero and proposal imagery are `<image-slot>` placeholders — drop in real photography.
