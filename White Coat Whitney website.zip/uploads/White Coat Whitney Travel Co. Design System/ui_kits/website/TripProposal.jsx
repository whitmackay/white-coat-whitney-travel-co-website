const { Tabs, Badge, Button } = window.WhiteCoatWhitneyTravelCoDesignSystem_ae13f6;
function TripProposal() {
  const [tab, setTab] = React.useState('Itinerary');
  const days = [
    {d:'Day 1–2', t:'Arrive Positano', b:'Private transfer from Naples, welcome dinner on the terrace.'},
    {d:'Day 3–4', t:'Amalfi & Ravello', b:'Driver-guided coastal day, lunch at a cliffside trattoria.'},
    {d:'Day 5–6', t:'Capri', b:'Private boat charter around the island, Blue Grotto by rowboat.'},
    {d:'Day 7', t:'Depart', b:'Late checkout, transfer to Naples airport.'}
  ];
  return (
    <div style={{maxWidth:860, margin:'0 auto', padding:'56px 48px 96px'}}>
      <div style={{fontFamily:'var(--font-mono)', fontSize:12, letterSpacing:'0.2em', textTransform:'uppercase', color:'var(--text-muted)'}}>Proposal · WCW-24417</div>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginTop:10}}>
        <div style={{fontFamily:'var(--font-display)', fontWeight:300, fontSize:40}}>Amalfi Coast, 7 nights</div>
        <Badge tone="accent">Awaiting your reply</Badge>
      </div>
      <div style={{height:280, marginTop:28}}>
        <image-slot id="proposal-hero" style={{width:'100%', height:'100%'}} shape="rounded" radius="6" placeholder="Drop a villa / coastline photo"></image-slot>
      </div>

      <div style={{marginTop:36}}>
        <Tabs tabs={['Itinerary','Inclusions','Investment']} active={tab} onChange={setTab} />
      </div>

      {tab === 'Itinerary' && (
        <div style={{marginTop:32, display:'flex', flexDirection:'column', gap:28}}>
          {days.map(day => (
            <div key={day.d} style={{display:'flex', gap:24, borderBottom:'1px solid var(--wcw-line)', paddingBottom:24}}>
              <div style={{width:110, fontFamily:'var(--font-mono)', fontSize:13, color:'var(--text-muted)', flexShrink:0, paddingTop:2}}>{day.d}</div>
              <div>
                <div style={{fontFamily:'var(--font-display)', fontSize:22, fontWeight:400}}>{day.t}</div>
                <div style={{fontFamily:'var(--font-body)', fontSize:16, color:'var(--text-secondary)', marginTop:6}}>{day.b}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'Inclusions' && (
        <ul style={{marginTop:32, fontFamily:'var(--font-body)', fontSize:17, color:'var(--text-secondary)', lineHeight:'var(--leading-relaxed)', paddingLeft:20}}>
          <li>Round-trip business class flights</li>
          <li>Private transfers throughout</li>
          <li>6 nights, ocean-view suite</li>
          <li>Full-day private boat charter</li>
          <li>Daily breakfast, two arranged dinners</li>
        </ul>
      )}

      {tab === 'Investment' && (
        <div style={{marginTop:32, fontFamily:'var(--font-mono)', fontSize:15, display:'flex', flexDirection:'column', gap:10, maxWidth:420}}>
          <div style={{display:'flex', justifyContent:'space-between', color:'var(--text-secondary)'}}><span>Flights (2 pax, business)</span><b style={{color:'var(--text-primary)'}}>$9,200</b></div>
          <div style={{display:'flex', justifyContent:'space-between', color:'var(--text-secondary)'}}><span>Accommodations</span><b style={{color:'var(--text-primary)'}}>$6,850</b></div>
          <div style={{display:'flex', justifyContent:'space-between', color:'var(--text-secondary)'}}><span>Transfers & charter</span><b style={{color:'var(--text-primary)'}}>$2,370</b></div>
          <div style={{display:'flex', justifyContent:'space-between', borderTop:'1px solid var(--wcw-line)', paddingTop:10, marginTop:4}}><span>Total</span><b>$18,420</b></div>
        </div>
      )}

      <div style={{marginTop:48, display:'flex', gap:16}}>
        <Button variant="primary">Approve proposal</Button>
        <Button variant="outline">Request changes</Button>
      </div>
    </div>
  );
}
window.TripProposal = TripProposal;
