const { Input, Select, Checkbox, Radio, Switch, Tag, Button, Toast } = window.WhiteCoatWhitneyTravelCoDesignSystem_ae13f6;
function Inquiry() {
  const [cabin, setCabin] = React.useState('business');
  const [flex, setFlex] = React.useState(false);
  const [flights, setFlights] = React.useState(true);
  const [sent, setSent] = React.useState(false);
  const [tags, setTags] = React.useState(['Coastal','All-inclusive']);

  if (sent) {
    return (
      <div style={{maxWidth:560, margin:'120px auto', padding:'0 24px', textAlign:'center'}}>
        <Toast tone="success">Inquiry sent — I'll reply within one business day.</Toast>
        <div style={{fontFamily:'var(--font-display)', fontWeight:300, fontSize:32, marginTop:32}}>Thank you.</div>
        <div style={{fontFamily:'var(--font-body)', fontSize:17, color:'var(--text-secondary)', marginTop:12}}>I'll review your dates and send a first proposal shortly.</div>
      </div>
    );
  }

  return (
    <div style={{maxWidth:640, margin:'0 auto', padding:'56px 48px 96px'}}>
      <div style={{fontFamily:'var(--font-mono)', fontSize:12, letterSpacing:'0.2em', textTransform:'uppercase', color:'var(--text-muted)'}}>Start an inquiry</div>
      <div style={{fontFamily:'var(--font-display)', fontWeight:300, fontSize:36, marginTop:10}}>Tell me where you're headed.</div>
      <div style={{fontFamily:'var(--font-body)', fontSize:17, color:'var(--text-secondary)', marginTop:10, lineHeight:'var(--leading-normal)'}}>A few details, and I'll take it from here.</div>

      <div style={{display:'flex', flexDirection:'column', gap:24, marginTop:40}}>
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:20}}>
          <Input label="Full name" placeholder="Jordan Alvarez" />
          <Input label="Email" placeholder="jordan@example.com" />
        </div>
        <Input label="Preferred dates" placeholder="Oct 12 – Oct 19" />
        <Select label="Trip type" options={['Leisure', 'Conference + leisure', 'Family']} />

        <div>
          <div style={{fontFamily:'var(--font-mono)', fontSize:11, letterSpacing:'0.08em', textTransform:'uppercase', color:'var(--text-muted)', marginBottom:10}}>Interests</div>
          <div style={{display:'flex', gap:10, flexWrap:'wrap'}}>
            {tags.map(t => <Tag key={t} onRemove={()=>setTags(tags.filter(x=>x!==t))}>{t}</Tag>)}
          </div>
        </div>

        <div>
          <div style={{fontFamily:'var(--font-mono)', fontSize:11, letterSpacing:'0.08em', textTransform:'uppercase', color:'var(--text-muted)', marginBottom:10}}>Cabin class</div>
          <div style={{display:'flex', gap:24}}>
            <Radio label="Premium economy" checked={cabin==='premium'} onChange={()=>setCabin('premium')} />
            <Radio label="Business" checked={cabin==='business'} onChange={()=>setCabin('business')} />
            <Radio label="First" checked={cabin==='first'} onChange={()=>setCabin('first')} />
          </div>
        </div>

        <Checkbox label="Include flight booking" checked={flights} onChange={setFlights} />
        <Switch label="Flexible on dates" checked={flex} onChange={setFlex} />

        <div style={{marginTop:12}}>
          <Button variant="primary" size="lg" onClick={()=>setSent(true)}>Send inquiry</Button>
        </div>
      </div>
    </div>
  );
}
window.Inquiry = Inquiry;
