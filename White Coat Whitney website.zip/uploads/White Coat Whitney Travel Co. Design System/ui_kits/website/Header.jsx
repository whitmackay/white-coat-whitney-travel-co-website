function Header({page, onNavigate}) {
  const items = ['Home', 'Trip Proposal', 'Inquire'];
  return (
    <div>
      <div style={{height:36, background:'repeating-linear-gradient(90deg, var(--wcw-blue) 0 6px, transparent 6px 30px, var(--pop-aperol) 30px 36px, transparent 36px 60px, var(--pop-pink) 60px 66px, transparent 66px 90px, var(--pop-lime) 90px 96px, transparent 96px 120px)', borderTop:'1px solid var(--wcw-line)', borderBottom:'1px solid var(--wcw-line)'}}></div>
      <div style={{display:'flex', flexDirection:'column', alignItems:'center', padding:'22px 48px 20px', borderBottom:'1px solid var(--wcw-line)', background:'var(--wcw-cream)'}}>
        <img src="../../assets/logo-transparent.png" style={{height:64, cursor:'pointer'}} onClick={()=>onNavigate('Home')} />
        <div style={{display:'flex', alignItems:'center', gap:14, marginTop:24, width:'100%', maxWidth:420}}>
          <div style={{flex:1, height:2, background:'repeating-linear-gradient(90deg, var(--wcw-blue) 0 4px, var(--pop-aperol) 4px 8px, var(--pop-pink) 8px 12px, var(--pop-lime) 12px 16px)'}}></div>
          <nav style={{display:'flex', gap:28, flexShrink:0}}>
            {items.map(i => (
              <span key={i} onClick={()=>onNavigate(i)} style={{fontFamily:'var(--font-mono)', fontSize:12, letterSpacing:'0.1em', textTransform:'uppercase', color: page===i ? 'var(--text-primary)' : 'var(--text-muted)', cursor:'pointer', borderBottom: page===i ? '1px solid var(--color-accent)' : '1px solid transparent', paddingBottom:4}}>{i}</span>
            ))}
          </nav>
          <div style={{flex:1, height:2, background:'repeating-linear-gradient(90deg, var(--wcw-blue) 0 4px, var(--pop-aperol) 4px 8px, var(--pop-pink) 8px 12px, var(--pop-lime) 12px 16px)'}}></div>
        </div>
      </div>
    </div>
  );
}
window.Header = Header;
