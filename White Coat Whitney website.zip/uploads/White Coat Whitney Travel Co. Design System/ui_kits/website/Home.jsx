const { Button, Card, Badge, Tag } = window.WhiteCoatWhitneyTravelCoDesignSystem_ae13f6;
function Home({onNavigate}) {
  return (
    <div>
      <div style={{position:'relative', height:520}}>
        <image-slot id="hero" style={{position:'absolute', inset:0, width:'100%', height:'100%'}} shape="rect" placeholder="Drop a coastline / hotel hero photo"></image-slot>
        <div style={{position:'absolute', inset:0, background:'linear-gradient(180deg, rgba(16,19,20,0.05), rgba(16,19,20,0.55))', pointerEvents:'none'}}></div>
        <div style={{position:'absolute', left:48, bottom:56, right:48, color:'#fff', pointerEvents:'none'}}>
          <div style={{fontFamily:'var(--font-mono)', fontSize:13, letterSpacing:'0.28em', textTransform:'uppercase', opacity:0.85}}>Full-service luxury travel</div>
          <div style={{fontFamily:'var(--font-display)', fontWeight:300, fontSize:'clamp(40px,6vw,76px)', lineHeight:1.05, marginTop:12, maxWidth:820}}>Journeys, arranged with care.</div>
          <div style={{marginTop:24, pointerEvents:'auto'}}><Button variant="pop" size="lg" onClick={()=>onNavigate('Inquire')}>Start an inquiry</Button></div>
        </div>
      </div>

      <div style={{padding:'72px 48px', maxWidth:1040, margin:'0 auto'}}>
        <div style={{fontFamily:'var(--font-mono)', fontSize:12, letterSpacing:'0.2em', textTransform:'uppercase', color:'var(--text-muted)'}}>For the schedule of a working professional</div>
        <div style={{fontFamily:'var(--font-display)', fontWeight:300, fontSize:32, marginTop:12, maxWidth:640, lineHeight:1.3}}>Your time is worth more than a spreadsheet of flight options. Tell me the dates — I'll handle the rest.</div>
      </div>

      <div style={{padding:'0 48px 72px', maxWidth:1040, margin:'0 auto'}}>
        <div style={{display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:24}}>
          <Card eyebrow="Amalfi Coast" title="7 nights, private villa" body="Includes transfers, a private chef, and a half-day sail." footer={<Tag pop="aperol">Coastal</Tag>} />
          <Card eyebrow="Kyoto" title="5 nights, ryokan stay" body="Private tea ceremony, driver on call, kaiseki dinners." footer={<Tag pop="pink">Culture</Tag>} />
          <Card eyebrow="Maldives" title="6 nights, overwater suite" body="Direct flights, all-inclusive, seaplane transfer arranged." footer={<Tag pop="lime">All-inclusive</Tag>} />
        </div>
      </div>

      <div style={{background:'var(--wcw-blue-dark)', color:'#fff', padding:'80px 48px', textAlign:'center'}}>
        <div style={{fontFamily:'var(--font-script)', fontSize:48}}>Whitney</div>
        <div style={{fontFamily:'var(--font-display)', fontWeight:300, fontSize:26, maxWidth:640, margin:'16px auto 0', lineHeight:1.4, opacity:0.9}}>"She had our entire honeymoon booked — flights, hotel upgrades, dinner reservations — before I finished my next shift."</div>
        <div style={{fontFamily:'var(--font-mono)', fontSize:12, letterSpacing:'0.15em', textTransform:'uppercase', opacity:0.6, marginTop:20}}>Dr. R. Nguyen, Emergency Medicine</div>
      </div>
    </div>
  );
}
window.Home = Home;
