# White Coat Whitney Travel Co. — Design System

## Company

White Coat Whitney Travel Co. is a full-service luxury travel agency run by a Physician Assistant/Associate‑Certified professional who is also a certified Fora travel agent. The brand targets busy, high-earning professionals — physicians, PAs, NPs, nurses, and adjacent professions like attorneys — who have the means for luxury travel but not the time to plan it. The value proposition is white-glove trip planning that removes the burden of research and logistics from an already-overextended clientele.

**Sources provided:** two brand logo exports (`uploads/WHITE COAT WHITNEY TRAVEL CO.png`, transparent background; `uploads/WHITE COAT WHITNEY TRAVEL CO white background.png`), and font/color notes (Canva fonts "Lovely May" and "Emitha", plus Roboto Mono; brand colors white, black, `#38B6FF`). No codebase, no Figma file, and no additional decks or screenshots were supplied. Everything in this system beyond the logo and stated fonts/colors — layout, components, copy voice — is originated to fit the brand, not sourced from an existing product.

## Index

- `styles.css` — root stylesheet, imports every token file below.
- `tokens/colors.css`, `tokens/typography.css`, `tokens/spacing.css` — design tokens.
- `assets/` — logo files (transparent + white-background versions).
- `guidelines/` — specimen cards for the Design System tab (Colors, Type, Spacing, Brand).
- `components/` — reusable UI primitives: `core/` (Button, IconButton, Badge, Tag), `forms/` (Input, Select, Checkbox, Radio, Switch), `surfaces/` (Card, Tabs), `feedback/` (Dialog, Tooltip, Toast).
- `ui_kits/website/` — click-through recreation of the marketing website: Home, Trip Proposal, Inquiry Form, Testimonials.
- `SKILL.md` — portable skill definition for use in Claude Code.

## Content fundamentals

**Voice:** warm, discreet, competent — a trusted concierge, not a salesperson. Confident and unhurried; never hypey or exclamation-heavy.

**Person:** speaks to the reader directly in second person ("you," "your next trip"), signs off in first person singular where personal ("I handle the details"). Whitney is a named, visible person behind the brand, not an anonymous "team."

**Casing:** headlines and eyebrows favor small caps / all-caps with wide letter-spacing (matching the logo's tracked caps), sentence case for body copy. Avoid title-case body text.

**Tone examples:**
- "Your time is worth more than a spreadsheet of flight options."
- "Tell me the dates. I'll handle the rest."
- "Built for the schedule of a working physician — because it's mine too."

**Emoji:** none. The brand's only illustrative mark is the fine-line paper-airplane flourish in the logo; no emoji, no decorative icon clutter in copy.

**What to avoid:** urgency language ("BOOK NOW," countdown timers), discount-driven phrasing, exclamation points, corporate-agency jargon ("synergy," "solutions").

## Visual foundations

**Color:** a restrained three-color system — ink black (`--wcw-black`), white/cream surfaces, and a single sky-blue accent (`--wcw-blue`, `#38B6FF`) used sparingly for links, active states, and small accents (never as a dominant fill). No gradients. Backgrounds are flat: warm off-white (`--wcw-cream`, `--wcw-sand`) rather than stark white, to feel considered rather than clinical.

**Type:** an editorial pairing — a light, wide-tracked serif (Cormorant, standing in for the brand's "Lovely May" serif style) for headlines and all-caps labels, and a thin flowing script (Beau Rivage, standing in for "Emitha") reserved for a single signature moment per layout (a name, a pull-quote signoff) — exactly as the logo uses it once for "Whitney." Body copy stays in the same serif family at a comfortable reading size; Roboto Mono appears only for functional/numeric detail (dates, prices, confirmation codes, itinerary line items) to visually separate "content" from "data."

**Spacing:** generous, magazine-like whitespace. An 4/8px-derived scale (`--space-1`…`--space-10`) but used loosely — sections breathe with 64–128px of vertical space rather than tight app-density padding.

**Imagery:** warm, natural-light travel photography (coastlines, hotel interiors, landscapes) — no stock-photo gloss, no heavy filters. Full-bleed hero imagery is the primary device for storytelling; supporting sections use imagery cropped to soft rectangles, never circles or blobs. No illustration system beyond the logo's own line-art plane; do not introduce new decorative illustration.

**Motion:** minimal and slow. Simple opacity/translate fades on scroll-in (`--duration-standard`, `--ease-standard`), no bounce, no springy easing — restraint over flourish.

**Hover / press states:** links and buttons darken toward black on hover (never lighten to a brighter blue); text links gain an underline on hover. Press states scale down subtly (~0.98) rather than changing color. Focus rings use a 2px accent-blue outline offset from the element.

**Borders & shadows:** hairline 1px borders in a warm neutral (`--wcw-line`), used more than shadows. Shadows are soft and rare — reserved for floating surfaces (dialogs, dropdowns), never on flat page cards. Cards are typically border-only, no shadow, no rounding beyond `--radius-md` (6px) — sharper corners read more editorial/luxury than heavily rounded ones.

**Corners:** small radii throughout (2–6px); pill radius reserved for pure UI chrome (tags, switches), not for content cards or buttons, to avoid a "soft app" feel inconsistent with the brand's editorial tone.

**Transparency / blur:** used sparingly — a translucent dark scrim (not blur) over hero imagery to keep header text legible; no frosted-glass panels elsewhere.

**Layout rules:** centered, generously margined single-column reading measure for text sections; asymmetric two-column split for image+text panels. A slim fixed header holds the wordmark left, nav right.

## Iconography

The provided assets contain no icon set or icon font — only the wordmark logo (which includes one bespoke line-art flourish: a small hand-drawn paper airplane with a dotted flight path, used once as the crossbar of the "t" in "Whitney"). No emoji or Unicode-glyph icons appear in the source material.

For UI and component icons, this system links **Lucide** from CDN (`unpkg.com/lucide-static` / `lucide` web font-free SVG set) — a thin-stroke, minimal line icon set chosen to match the fine hairline weight of the logo's own line art. This is a flagged substitution: no icon set was provided by the brand, so Lucide's stroke weight (1.5px) was matched to the logo's line weight by eye. Icons are used only where functionally necessary (form fields, nav, close/menu affordances) — never decoratively.

## Fonts — flagged substitution

"Lovely May" and "Emitha" are Canva-marketplace fonts, not distributed on Google Fonts or otherwise freely licensable, so they cannot be embedded here as-is. Substitutes used, matched by shape and weight:

- **Lovely May** (thin wide-tracked display serif, used for "WHITE COAT" / "TRAVEL CO.") → **Cormorant** (light weight), a free Google Font with the same tall, thin, high-contrast serif letterforms.
- **Emitha** (thin flowing signature script, used for "Whitney") → **Mrs Saint Delafield**, a free Google Font script with a comparably delicate, elegant connected line.
- **Roboto Mono** — used as specified; available directly on Google Fonts.

**Ask:** if you own licensed copies of Lovely May and Emitha (desktop/webfont files), share them and this system will swap in the real brand fonts in place of the substitutes above.

## Intentional additions

No component library, codebase, or Figma file was provided, so the component set below is an original standard kit (Button, IconButton, Input, Select, Checkbox, Radio, Switch, Card, Badge, Tag, Tabs, Dialog, Tooltip) sized to a small marketing site + inquiry flow — not sourced from an existing product.
